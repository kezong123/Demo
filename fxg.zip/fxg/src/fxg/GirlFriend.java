package fxg;

public class GirlFriend {
	private int YanZhi;
	private int TiZhong;
	private int ShenGao;
	private int ShengQi;
	private int Ai;
	public GirlFriend(){	
	}
	public int getyanzhi(){	
		return YanZhi;
	}
    public void setYanZhi(int yanzhi){
    	YanZhi=yanzhi;
    }
	public int getTiZhong(){
		return TiZhong;
	}
		  public void setTiZhong(int tizhong){
		    	TiZhong=tizhong;
		  }
		  public int getShenGao(){
				return ShenGao;
			}
		  public void setShenGao(int shengao){
		    	ShenGao=shengao;
		  }
		  public int getShengQi(){
				return ShengQi;
			}
		  public void setShengQi(int shengqi){
		    	ShengQi=shengqi;
		  }
		  public int getAi(){
				return Ai;
			}
		  public void setAi(int ai){
		    	Ai=ai;
		  }
	}
